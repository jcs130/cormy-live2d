CorMy 可米 · 奶油猫娘（酒狐二创）
1.2.0-preview | 2026-10-13

本版直接采用 YSM 内置“大酒狐 / wine_fox/13_matured”作为底模。
保留原作脸型、表情、胸部曲面和主要动作骨架。
刘海左右两侧为橘色并连接耳根，中间留奶油白；耳朵尖端为白色。
原女仆式围裙、长裙、腰间大蝴蝶结和喇叭袖已移除。
按设计图改成奶油白敞开外套、棕色高领针织内搭、翻边短裤和短靴；
增加小扣带、腰带和侧袋，第一人称袖口也同步更新。
裤管各自跟随左右腿骨骼；手部保留原几何并改成与腿部一致的肤色。
后发仍为及肩短发。
橘白猫尾加粗并增加弧度，尾端上翘，在正面、侧面、背面都更明显。
背后的单个橘色爱心移到衣服上背部，露在短发下方。
这是一份酒狐衍生作品，不是可米原创底模。署名与许可见 ATTRIBUTION.txt。

模型包
  CorMy-WineFox-Cream-Preview.zip
  原生目录：ysm/cormy-winefox-cream/
  内含 ysm.json、主模型、第一人称手臂、贴图和原有动作。
  保留打招呼、鼓掌、卖萌及舞蹈入口，隐藏不适用的狐形与雨伞入口。

编辑素材
  CorMy-WineFox-Editable-Source.zip
  models/main.json 是可导入 Blockbench 的 Bedrock 几何源文件；
  同时载入 textures/cormy-cream.png，动作文件位于 animations/。
  models/arm.json 单独编辑，和主模型共用同一张 2048×2048 贴图。
  后发通过三个独立的 CormyHairCrop 骨骼在 pre_parallel0 中常驻缩放，
  保留原发束的完整衔接；只看几何时仍会显示未缩短的原始发束。
  在编辑器导入主动画并启用这三个缩放通道，才能看到交付时的短发效果。
  独立骨骼避免原有攀爬等动作覆盖短发比例。
  没有把渲染截图当作模型，也没有把 ZIP 改后缀冒充加密 .ysm。
  source/upstream/13_matured/ 保存本次使用的未修改原始资产与原署名。
  source/build.cjs 保存改色和猫尾制作过程，source/outfit.cjs 保存服装制作过程；
  source/material-space.mjs 按原生模型旋转后的坐标定位白耳尖和连贯刘海。
  需要 Node.js 与 sharp。
  复建：node source/build.cjs
  若 sharp 不在普通模块路径，可把 CORMY_SHARP 指向已安装的 sharp。
  source/render-preview.py 与 pose-check.py 仅用于离线检查，需 Python、
  NumPy、Pillow 和可从 PATH 调用的 node。预览依赖的许可也保留在 vendor 中。

使用方式
  YSM 支持未加密目录与 ZIP。解压模型包，将 cormy-winefox-cream 目录放入
  对应游戏实例的 config/yes_steve_model/custom/，保持 ysm.json 的目录结构。
  在 YSM 模型选择界面寻找“CorMy 可米 · 奶油猫娘（酒狐二创）”。
  多人服务器可能需要其资源分发流程；本次没有改变正式服绑定或启动客户端。
  官方格式说明：https://ysm.cfpa.team/wiki/type/

已做的检查
  - 读取并渲染实际交付的几何与贴图，展示正、侧前、背面和脸部。
  - 数值抽样检查走路、挥手、眨眼和第一人称手臂资产。
  - 检查文件引用、骨骼层级、改动范围、原动画保留和贴图区域隔离。
  - 检查原女仆服装的几何确已移除、左右裤管的挂接、第一人称骨架保留。
  结果与精确哈希见 source/validation.json。

尚未验证
  没有运行 Minecraft Java / YSM，所以游戏里的状态切换、完整 Molang、
  尾巴物理、持物、多人资源分发与帧率尚未验证。
  离线动作图只执行数值通道和继承的尾巴正弦摆动，不替代游戏实测。
  Blockbench 图形界面导入尚未验证；交付的是原生 Bedrock 源文件。
  当前按要求保持服务停止；没有加载新模型、重连或重启服务。

许可
  CC BY-NC-SA 4.0（署名、非商业、相同方式共享）。
  商业直播使用本模型，需要另行取得相应原作者的许可。
  修改后仍须保留原作来源与作者，不能作为原创底模重新声明所有权。

